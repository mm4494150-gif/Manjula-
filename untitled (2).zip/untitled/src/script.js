// Add event listener to the form submission

document.querySelector('form').addEventListener('submit', (e) => {

    e.preventDefault();

    // Get the form data

    const name = document.querySelector('input[type="text"]').value;

    const email = document.querySelector('input[type="email"]').value;

    const message = document.querySelector('textarea').value;

    // Send the form data to your server or email service

    console.log(`Name: ${name}, Email: ${email}, Message: ${message}`);

});